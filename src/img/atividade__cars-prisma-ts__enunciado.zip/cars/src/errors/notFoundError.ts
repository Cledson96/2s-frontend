export default function notFoundError() {
  return {
    name: "NotFoundError",
    message: "No results for this search!"
  }
}